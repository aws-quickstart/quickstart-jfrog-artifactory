const { Client } = require('pg');
const { promisify } = require('util')
var response = require('cfn-response')

exports.handler = (event, context) => {
  console.log("REQUEST RECEIVED:\n" + JSON.stringify(event))
  // For Delete requests, immediately send a SUCCESS response.
  if (event.RequestType == "Delete") {
      response.send(event, context, "SUCCESS")
      return
  }
  (async () => {
    try {
        const connectionString = `postgresql://${event.ResourceProperties.DatabaseUser}:${event.ResourceProperties.DatabasePassword}@${event.ResourceProperties.XrayMasterDatabaseUrl}`;
        console.log(connectionString);
        const client = new Client({
                        connectionString: connectionString
                    });
        await client.connect();
        console.log('start queries');

        let query = `CREATE USER ${event.ResourceProperties.XrayDatabaseUser} WITH PASSWORD '${event.ResourceProperties.XrayDatabasePassword}'`;
        await client.query(query)
            .catch(e => console.error(e.stack));

        query = `GRANT ${event.ResourceProperties.XrayDatabaseUser} to ${event.ResourceProperties.DatabaseUser}`;
        await client.query(query)
            .catch(e => console.error(e.stack));

        query = `CREATE DATABASE xraydb WITH OWNER=${event.ResourceProperties.XrayDatabaseUser}`;
        await client.query(query)
            .catch(e => console.error(e.stack));

        query = `GRANT ALL PRIVILEGES ON DATABASE xraydb TO ${event.ResourceProperties.XrayDatabaseUser}`;
        await client.query(query)
            .catch(e => console.error(e.stack));
        console.log('end queries');

        client.end();
        
    } catch (err) {
        console.error(err);
        response.send(event, context, response.FAILED, err)
    }
  })().then(response.send(event, context, response.SUCCESS, {}));
  
}
